package com.example.command;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.business.User;
import com.example.service.UserService;

public class ListUsersCommand implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse repsonse){
		
		UserService userService = new UserService();
		String forwardToJsp = "";		
	
		HttpSession session = request.getSession();
		String clientSessionId = session.getId();
		session.setAttribute("loggedSessionId", clientSessionId);
		ArrayList<User> users = new ArrayList<User>();
		try {
			users = userService.getAllUsers();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		session.setAttribute("users", users);
				
		forwardToJsp = "/listUsers.jsp";				

		return forwardToJsp;
	}
}

