package com.example.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.example.business.User;
import com.example.dao.UserDao;
import com.example.exceptions.DaoException;

public class UserService {

	UserDao dao = new UserDao();
	
	public User login(String username, String password){
		
		User u = null;
		try {			
			u = dao.findUserByUsernamePassword(username, password);
		} 
		catch (DaoException e) {
			e.printStackTrace();
		}
		return u;
		
	}
	
	
	public ArrayList<User> getAllUsers() throws SQLException{
		
		ArrayList<User> users = new ArrayList<User>();
		
		try 
		{			
			users = dao.getAllUsers();
		} 
		catch (DaoException e) {
			e.printStackTrace();
		}
		return users;
		
	}

	
	
}
